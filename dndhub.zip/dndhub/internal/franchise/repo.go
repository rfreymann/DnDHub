package franchise

import (
	"context"
	"database/sql"

	"github.com/google/uuid"
)

type Repository struct {
	db *sql.DB
}

func NewRepository(db *sql.DB) *Repository {
	return &Repository{db: db}
}

func (r *Repository) CreateFranchise(ctx context.Context, userID uuid.UUID, name string) (Franchise, error) {
	var f Franchise
	err := r.db.QueryRowContext(ctx, `
		INSERT INTO franchises (user_id, name)
		VALUES ($1, $2)
		RETURNING id, user_id, name,
		          funds_cents, property_value_cents,
		          unskilled_workers, lowskilled_workers, highskilled_workers,
		          cost_unskilled_cents, cost_lowskilled_cents, cost_highskilled_cents,
		          revenue_modifier_bp, upkeep_modifier_bp,
		          created_at, updated_at
	`, userID, name).Scan(
		&f.ID, &f.UserID, &f.Name,
		&f.FundsCents, &f.PropertyValueCents,
		&f.UnskilledWorkers, &f.LowskilledWorkers, &f.HighskilledWorkers,
		&f.CostUnskilledCents, &f.CostLowskilledCents, &f.CostHighskilledCents,
		&f.RevenueModifierBP, &f.UpkeepModifierBP,
		&f.CreatedAt, &f.UpdatedAt,
	)
	return f, err
}

func (r *Repository) GetFranchisesByUser(ctx context.Context, userID uuid.UUID) ([]Franchise, error) {
	rows, err := r.db.QueryContext(ctx, `
		SELECT id, user_id, name,
		       funds_cents, property_value_cents,
		       unskilled_workers, lowskilled_workers, highskilled_workers,
		       cost_unskilled_cents, cost_lowskilled_cents, cost_highskilled_cents,
		       revenue_modifier_bp, upkeep_modifier_bp,
		       created_at, updated_at
		FROM franchises
		WHERE user_id = $1
		ORDER BY created_at ASC
	`, userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []Franchise
	for rows.Next() {
		var f Franchise
		if err := rows.Scan(
			&f.ID, &f.UserID, &f.Name,
			&f.FundsCents, &f.PropertyValueCents,
			&f.UnskilledWorkers, &f.LowskilledWorkers, &f.HighskilledWorkers,
			&f.CostUnskilledCents, &f.CostLowskilledCents, &f.CostHighskilledCents,
			&f.RevenueModifierBP, &f.UpkeepModifierBP,
			&f.CreatedAt, &f.UpdatedAt,
		); err != nil {
			return nil, err
		}
		list = append(list, f)
	}
	return list, rows.Err()
}

func (r *Repository) GetFranchiseByID(ctx context.Context, userID, franchiseID uuid.UUID) (Franchise, error) {
	var f Franchise
	err := r.db.QueryRowContext(ctx, `
		SELECT id, user_id, name,
		       funds_cents, property_value_cents,
		       unskilled_workers, lowskilled_workers, highskilled_workers,
		       cost_unskilled_cents, cost_lowskilled_cents, cost_highskilled_cents,
		       revenue_modifier_bp, upkeep_modifier_bp,
		       created_at, updated_at
		FROM franchises
		WHERE id = $1 AND user_id = $2
	`, franchiseID, userID).Scan(
		&f.ID, &f.UserID, &f.Name,
		&f.FundsCents, &f.PropertyValueCents,
		&f.UnskilledWorkers, &f.LowskilledWorkers, &f.HighskilledWorkers,
		&f.CostUnskilledCents, &f.CostLowskilledCents, &f.CostHighskilledCents,
		&f.RevenueModifierBP, &f.UpkeepModifierBP,
		&f.CreatedAt, &f.UpdatedAt,
	)
	return f, err
}

func (r *Repository) GetWorkersByFranchise(ctx context.Context, franchiseID uuid.UUID) ([]UniqueWorker, error) {
	rows, err := r.db.QueryContext(ctx, `
		SELECT id, franchise_id, name, monthly_cost_cents,
		       creativity, discipline, charisma, efficiency, exploration,
		       notes, created_at, updated_at
		FROM unique_workers
		WHERE franchise_id = $1
		ORDER BY created_at ASC
	`, franchiseID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []UniqueWorker
	for rows.Next() {
		var w UniqueWorker
		if err := rows.Scan(
			&w.ID, &w.FranchiseID, &w.Name, &w.MonthlyCostCents,
			&w.Creativity, &w.Discipline, &w.Charisma, &w.Efficiency, &w.Exploration,
			&w.Notes, &w.CreatedAt, &w.UpdatedAt,
		); err != nil {
			return nil, err
		}
		list = append(list, w)
	}
	return list, rows.Err()
}
