package franchise

import (
	"encoding/json"
	"net/http"

	"github.com/rafrey/dndhub/internal/user"

	"github.com/go-chi/chi/v5"
	"github.com/google/uuid"
)

type Handler struct {
	service *Service
}

func NewHandler(s *Service) *Handler {
	return &Handler{service: s}
}

func (h *Handler) Routes() chi.Router {
	r := chi.NewRouter()
	r.Post("/create", h.handleCreateFranchise)
	r.Get("/", h.handleListFranchises)
	r.Get("/{id}", h.handleGetFranchise)
	return r
}

func (h *Handler) handleCreateFranchise(w http.ResponseWriter, r *http.Request) {
	userIDStr, ok := user.GetUserID(r)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}

	var body struct {
		Name string `json:"name"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	uid, err := uuid.Parse(userIDStr)
	if err != nil {
		http.Error(w, "invalid user id", http.StatusUnauthorized)
		return
	}

	fr, err := h.service.CreateFranchise(r.Context(), uid, body.Name)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(fr)
}

func (h *Handler) handleListFranchises(w http.ResponseWriter, r *http.Request) {
	userIDStr, ok := user.GetUserID(r)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}

	uid, err := uuid.Parse(userIDStr)
	if err != nil {
		http.Error(w, "invalid user id", http.StatusUnauthorized)
		return
	}

	franchises, err := h.service.ListFranchises(r.Context(), uid)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(franchises)
}

func (h *Handler) handleGetFranchise(w http.ResponseWriter, r *http.Request) {
	userIDStr, ok := user.GetUserID(r)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}

	uid, err := uuid.Parse(userIDStr)
	if err != nil {
		http.Error(w, "invalid user id", http.StatusUnauthorized)
		return
	}

	franchiseIDStr := chi.URLParam(r, "id")
	fid, err := uuid.Parse(franchiseIDStr)
	if err != nil {
		http.Error(w, "invalid franchise id", http.StatusBadRequest)
		return
	}

	fr, err := h.service.GetFranchiseWithWorkers(r.Context(), uid, fid)
	if err != nil {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(fr)
}
