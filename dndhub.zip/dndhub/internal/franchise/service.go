package franchise

import (
	"context"

	"github.com/google/uuid"
)

type Service struct {
	repo *Repository
}

func NewService(repo *Repository) *Service {
	return &Service{repo: repo}
}

func (s *Service) CreateFranchise(ctx context.Context, userID uuid.UUID, name string) (Franchise, error) {
	return s.repo.CreateFranchise(ctx, userID, name)
}

func (s *Service) ListFranchises(ctx context.Context, userID uuid.UUID) ([]Franchise, error) {
	return s.repo.GetFranchisesByUser(ctx, userID)
}

func (s *Service) GetFranchise(ctx context.Context, userID, franchiseID uuid.UUID) (Franchise, error) {
	return s.repo.GetFranchiseByID(ctx, userID, franchiseID)
}

func (s *Service) GetFranchiseWithWorkers(ctx context.Context, userID, franchiseID uuid.UUID) (FranchiseWithWorkers, error) {
	f, err := s.repo.GetFranchiseByID(ctx, userID, franchiseID)
	if err != nil {
		return FranchiseWithWorkers{}, err
	}

	workers, err := s.repo.GetWorkersByFranchise(ctx, franchiseID)
	if err != nil {
		return FranchiseWithWorkers{}, err
	}

	return FranchiseWithWorkers{
		Franchise: f,
		Workers:   workers,
	}, nil
}
